mka bacon TARGET_TOOLS_PREFIX=`pwd`/android-toolchain-eabi/bin/arm-linux-androideabi- TARGET_PRODUCT=mirage_$1

cd out/target/product/$1

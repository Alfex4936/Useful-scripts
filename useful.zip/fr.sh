#!/bin/sh

# Include colors
. colors
echo -e "Moving to "$CL_YLW"frameworks/base"$CL_RST
cd frameworks/base

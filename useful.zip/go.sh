. make.sh maguro no 12
